import React  from 'react'
import'./WeatherSavePage.css';



function WeatherSavePage() {
  
  

  return (
    <div>
        <div className='Weather'><h1>Weather location Dashboard</h1></div>
        
        
        
    </div>
  )
}



export default WeatherSavePage